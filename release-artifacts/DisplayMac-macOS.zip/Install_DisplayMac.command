#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "Installing DisplayMac to Applications..."
xattr -cr "$DIR/DisplayMac.app" 2>/dev/null || true
cp -R "$DIR/DisplayMac.app" /Applications/
xattr -cr /Applications/DisplayMac.app 2>/dev/null || true
echo "Installation complete! Opening DisplayMac..."
open /Applications/DisplayMac.app
